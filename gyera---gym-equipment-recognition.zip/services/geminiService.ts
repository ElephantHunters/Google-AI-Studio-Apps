
import { GoogleGenAI, Type, Schema } from "@google/genai";
import { EquipmentData, DifficultyLevel } from "../types";
import { SYSTEM_INSTRUCTION } from "../constants";
import { BoundingBox } from "../utils/imageUtils";

// Define the schema for the JSON response
const equipmentSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    identified: {
      type: Type.BOOLEAN,
      description: "True if gym equipment is clearly identified, false otherwise.",
    },
    errorReason: {
      type: Type.STRING,
      description: "If identified is false, explain why (e.g., 'Image too blurry', 'Not gym equipment').",
    },
    name: {
      type: Type.STRING,
      description: "The official name of the equipment.",
    },
    alternativeNames: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "Common slang or alternative names used in gyms.",
    },
    description: {
      type: Type.STRING,
      description: "A 1-2 sentence overview of the machine's purpose.",
    },
    primaryMuscles: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "List of primary muscles targeted.",
    },
    difficulty: {
      type: Type.STRING,
      enum: ["Beginner", "Intermediate", "Advanced"],
      description: "The difficulty level of using this machine.",
    },
    youtubeSearchQuery: {
      type: Type.STRING,
      description: "A highly optimized YouTube search query to find the best tutorial for this specific machine (e.g., 'How to use Life Fitness Leg Press properly').",
    },
    safetyTips: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "3-4 short, critical safety tips for a beginner.",
    },
  },
  required: ["identified", "name", "description", "primaryMuscles", "difficulty", "youtubeSearchQuery", "safetyTips"],
};

const faceSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    faces: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          ymin: { type: Type.NUMBER },
          xmin: { type: Type.NUMBER },
          ymax: { type: Type.NUMBER },
          xmax: { type: Type.NUMBER },
        },
        required: ["ymin", "xmin", "ymax", "xmax"],
      },
    },
  },
};

const getAI = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API Key is missing.");
  }
  return new GoogleGenAI({ apiKey });
};

export const detectFaces = async (base64Image: string): Promise<BoundingBox[]> => {
  const ai = getAI();
  
  try {
    // Use gemini-2.5-flash for fast detection
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: {
        parts: [
          { inlineData: { mimeType: "image/jpeg", data: base64Image } },
          { text: "Detect bounding boxes of all human faces in this image. Return normalized coordinates (0.0 to 1.0)." },
        ],
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: faceSchema,
        temperature: 0, // Strict for coordinates
      },
    });

    const text = response.text;
    if (!text) return [];
    
    const data = JSON.parse(text) as { faces: BoundingBox[] };
    return data.faces || [];
  } catch (error) {
    console.warn("Face detection failed, proceeding without blurring:", error);
    return [];
  }
};

export const analyzeGymEquipment = async (base64Image: string): Promise<EquipmentData> => {
  const ai = getAI();

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: base64Image,
            },
          },
          {
            text: "Analyze this image. Identify the gym equipment and provide usage details. Ignore any people in the frame (faces should be blurred).",
          },
        ],
      },
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        responseMimeType: "application/json",
        responseSchema: equipmentSchema,
        temperature: 0.1, // Low temperature for factual accuracy
      },
    });

    const text = response.text;
    if (!text) {
      throw new Error("No response text received from Gemini.");
    }

    const data = JSON.parse(text) as EquipmentData;
    return data;

  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    throw error;
  }
};
