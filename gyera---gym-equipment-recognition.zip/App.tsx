
import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { ImageUploader } from './components/ImageUploader';
import { ResultCard } from './components/ResultCard';
import { FeedbackModal } from './components/FeedbackModal';
import { analyzeGymEquipment, detectFaces } from './services/geminiService';
import { blurFaces } from './utils/imageUtils';
import { AnalysisState } from './types';
import { Loader2, ArrowLeft, Sparkles, ShieldCheck } from 'lucide-react';

const App: React.FC = () => {
  const [state, setState] = useState<AnalysisState>({
    status: 'idle',
    data: null,
    errorMessage: null,
    imagePreview: null,
  });

  const [loadingMessage, setLoadingMessage] = useState("Identifying machine...");
  const [isFeedbackOpen, setIsFeedbackOpen] = useState(false);

  const handleImageSelected = async (base64: string) => {
    // Initial state with original image
    const initialPreview = `data:image/jpeg;base64,${base64}`;
    
    setState({
      status: 'analyzing',
      data: null,
      errorMessage: null,
      imagePreview: initialPreview,
    });
    
    setLoadingMessage("Scanning for privacy...");

    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });

    try {
      // Step 1: Detect Faces
      const faces = await detectFaces(base64);
      
      let processedBase64 = base64;

      // Step 2: Blur Faces if detected
      if (faces.length > 0) {
        setLoadingMessage("Blurring faces...");
        processedBase64 = await blurFaces(base64, faces);
        
        // Update preview with blurred image
        setState(prev => ({
          ...prev,
          imagePreview: `data:image/jpeg;base64,${processedBase64}`
        }));
      }

      // Step 3: Analyze Equipment
      setLoadingMessage("Analyzing equipment...");
      const result = await analyzeGymEquipment(processedBase64);
      
      setState(prev => ({
        ...prev,
        status: 'success',
        data: result,
      }));
    } catch (error) {
      console.error(error);
      setState(prev => ({
        ...prev,
        status: 'error',
        errorMessage: "Unable to analyze the image. Please check your internet connection and try again.",
      }));
    }
  };

  const resetApp = () => {
    setState({
      status: 'idle',
      data: null,
      errorMessage: null,
      imagePreview: null,
    });
    setLoadingMessage("Identifying machine...");
  };

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col">
      <Header />

      <main className="flex-grow px-4 py-8 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto space-y-8">

          {/* Idle State: Intro & Upload */}
          {state.status === 'idle' && (
            <div className="space-y-8 animate-fade-in-up">
              <div className="text-center space-y-4 mt-8">
                <h2 className="text-4xl md:text-5xl font-bold text-white tracking-tight">
                  Master the <span className="text-emerald-400">Gym</span>
                </h2>
                <p className="text-slate-400 text-lg max-w-xl mx-auto">
                  Unsure what that machine does? Upload a photo, and our AI will explain the equipment, muscles targeted, and proper form.
                </p>
              </div>

              <ImageUploader onImageSelected={handleImageSelected} />
              
              {/* Features Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-12">
                {[
                  { icon: "🎯", title: "Instant ID", desc: "Recognizes complex gym machinery instantly." },
                  { icon: "💪", title: "Muscle Focus", desc: "Know exactly which muscle groups you're working." },
                  { icon: "🛡️", title: "Privacy First", desc: "Automatically blurs faces in photos before analysis." }
                ].map((feature, i) => (
                  <div key={i} className="bg-slate-800/50 p-4 rounded-xl border border-slate-700 text-center">
                    <div className="text-3xl mb-2">{feature.icon}</div>
                    <h3 className="text-white font-semibold">{feature.title}</h3>
                    <p className="text-slate-400 text-sm">{feature.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Analyzing State */}
          {state.status === 'analyzing' && (
            <div className="flex flex-col items-center justify-center py-20 space-y-6 animate-pulse">
              <div className="relative">
                {state.imagePreview && (
                   <img 
                     src={state.imagePreview} 
                     alt="Analyzing" 
                     className="w-32 h-32 object-cover rounded-2xl opacity-50 blur-sm"
                   />
                )}
                <div className="absolute inset-0 flex items-center justify-center">
                  <Loader2 className="w-12 h-12 text-emerald-400 animate-spin" />
                </div>
              </div>
              <div className="text-center">
                <h3 className="text-xl font-semibold text-white mb-1">
                  {loadingMessage}
                </h3>
                <p className="text-slate-400 text-sm">Powered by Gemini AI</p>
              </div>
            </div>
          )}

          {/* Success State */}
          {state.status === 'success' && state.data && (
            <div className="space-y-6">
              <button 
                onClick={resetApp}
                className="flex items-center text-slate-400 hover:text-white transition-colors"
              >
                <ArrowLeft className="w-4 h-4 mr-1" /> Scan Another
              </button>

              <div className="grid md:grid-cols-2 gap-6">
                {/* Image Preview */}
                <div className="relative aspect-square md:aspect-auto md:h-full rounded-2xl overflow-hidden border border-slate-700 bg-slate-950">
                   {state.imagePreview && (
                    <div className="absolute inset-0 flex items-center justify-center p-6">
                      <img 
                        src={state.imagePreview} 
                        alt="Analyzed equipment" 
                        className="w-full h-full object-contain rounded-lg shadow-xl"
                      />
                    </div>
                  )}
                  <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-slate-950 via-slate-950/60 to-transparent p-4 pointer-events-none">
                     <div className="flex items-center gap-2 text-emerald-400 text-sm font-medium">
                        <Sparkles className="w-4 h-4" /> AI Analysis Complete
                     </div>
                  </div>
                  <div className="absolute top-4 right-4">
                      <div className="bg-slate-900/80 backdrop-blur-sm text-emerald-400 text-xs font-medium px-2 py-1 rounded-full border border-emerald-500/30 flex items-center gap-1">
                        <ShieldCheck className="w-3 h-3" /> Privacy Protected
                      </div>
                  </div>
                </div>

                {/* Results */}
                <ResultCard 
                  data={state.data} 
                  onSuggestCorrection={() => setIsFeedbackOpen(true)}
                />
              </div>
            </div>
          )}

          {/* Error State */}
          {state.status === 'error' && (
            <div className="text-center py-12">
              <div className="bg-red-500/10 p-4 rounded-full inline-block mb-4">
                <Sparkles className="w-8 h-8 text-red-400" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2">Analysis Failed</h3>
              <p className="text-slate-400 mb-6">{state.errorMessage}</p>
              <button 
                onClick={resetApp}
                className="bg-slate-800 hover:bg-slate-700 text-white px-6 py-2 rounded-lg transition-colors"
              >
                Try Again
              </button>
            </div>
          )}

        </div>
      </main>
      
      <FeedbackModal 
        isOpen={isFeedbackOpen} 
        onClose={() => setIsFeedbackOpen(false)}
        currentName={state.data?.name}
      />

      <Footer />
    </div>
  );
};

export default App;
