import React, { useState, useRef } from 'react';
import { X, Upload, Check, Loader2, AlertCircle } from 'lucide-react';

interface FeedbackModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentName?: string;
}

export const FeedbackModal: React.FC<FeedbackModalProps> = ({ isOpen, onClose, currentName }) => {
  const [step, setStep] = useState<'form' | 'submitting' | 'success'>('form');
  const [correctName, setCorrectName] = useState('');
  const [comments, setComments] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setStep('submitting');

    // Simulate API call
    setTimeout(() => {
      console.log("Feedback Submitted:", {
        originalName: currentName,
        suggestedName: correctName,
        comments,
        file: selectedFile ? selectedFile.name : 'No file'
      });
      setStep('success');
    }, 1500);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setSelectedFile(e.target.files[0]);
    }
  };

  const handleClose = () => {
    setStep('form');
    setCorrectName('');
    setComments('');
    setSelectedFile(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-slate-900/80 backdrop-blur-sm transition-opacity"
        onClick={handleClose}
      />

      {/* Modal Content */}
      <div className="relative w-full max-w-md bg-slate-800 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden animate-fade-in">
        
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-700 bg-slate-800/50">
          <h3 className="text-lg font-semibold text-white">Suggest Correction</h3>
          <button 
            onClick={handleClose}
            className="p-1 hover:bg-slate-700 rounded-full text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6">
          {step === 'success' ? (
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-emerald-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Check className="w-8 h-8 text-emerald-500" />
              </div>
              <h4 className="text-xl font-semibold text-white mb-2">Feedback Received!</h4>
              <p className="text-slate-400 mb-6">
                Thank you for helping us improve. Our team will review your suggestion to update the model.
              </p>
              <button
                onClick={handleClose}
                className="bg-slate-700 hover:bg-slate-600 text-white px-6 py-2 rounded-lg transition-colors font-medium"
              >
                Close
              </button>
            </div>
          ) : step === 'submitting' ? (
            <div className="flex flex-col items-center justify-center py-12">
              <Loader2 className="w-10 h-10 text-emerald-500 animate-spin mb-4" />
              <p className="text-slate-300">Submitting feedback...</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="bg-slate-900/50 p-3 rounded-lg border border-slate-700/50 flex items-start gap-3 mb-4">
                <AlertCircle className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
                <div className="text-sm">
                  <p className="text-slate-400">Identified as:</p>
                  <p className="text-white font-medium">{currentName || 'Unknown Equipment'}</p>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">
                  Correct Equipment Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={correctName}
                  onChange={(e) => setCorrectName(e.target.value)}
                  placeholder="e.g. Seated Leg Curl"
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-colors"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">
                  Upload Clearer Image <span className="text-slate-500 font-normal">(Optional)</span>
                </label>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  accept="image/*"
                  className="hidden"
                />
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full border border-dashed border-slate-600 hover:border-emerald-500 bg-slate-900/30 hover:bg-slate-900/50 rounded-lg p-4 cursor-pointer transition-colors text-center"
                >
                  {selectedFile ? (
                    <div className="flex items-center justify-center gap-2 text-emerald-400">
                      <Check className="w-4 h-4" />
                      <span className="text-sm truncate max-w-[200px]">{selectedFile.name}</span>
                    </div>
                  ) : (
                    <div className="flex items-center justify-center gap-2 text-slate-400">
                      <Upload className="w-4 h-4" />
                      <span className="text-sm">Choose file to upload</span>
                    </div>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-1">
                  Comments <span className="text-slate-500 font-normal">(Optional)</span>
                </label>
                <textarea
                  value={comments}
                  onChange={(e) => setComments(e.target.value)}
                  placeholder="Any details about the model or variant..."
                  rows={3}
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-colors resize-none"
                />
              </div>

              <div className="pt-2 flex gap-3">
                <button
                  type="button"
                  onClick={handleClose}
                  className="flex-1 bg-transparent border border-slate-600 hover:border-slate-500 text-slate-300 py-2.5 rounded-lg transition-colors font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white py-2.5 rounded-lg transition-colors font-medium shadow-lg shadow-emerald-900/20"
                >
                  Submit Feedback
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};