import React from 'react';
import { EquipmentData, DifficultyLevel } from '../types';
import { Youtube, Activity, AlertTriangle, Info, CheckCircle, Flag } from 'lucide-react';

interface ResultCardProps {
  data: EquipmentData;
  onSuggestCorrection: () => void;
}

const DifficultyBadge: React.FC<{ level: DifficultyLevel }> = ({ level }) => {
  const colors = {
    [DifficultyLevel.Beginner]: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30",
    [DifficultyLevel.Intermediate]: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30",
    [DifficultyLevel.Advanced]: "bg-red-500/20 text-red-400 border-red-500/30",
  };

  return (
    <span className={`px-3 py-1 rounded-full text-xs font-semibold border ${colors[level]}`}>
      {level}
    </span>
  );
};

export const ResultCard: React.FC<ResultCardProps> = ({ data, onSuggestCorrection }) => {
  if (!data.identified) {
    return (
      <div className="p-6 bg-red-900/20 border border-red-900/50 rounded-2xl text-center">
        <AlertTriangle className="w-12 h-12 text-red-500 mx-auto mb-4" />
        <h3 className="text-xl font-bold text-white mb-2">Could Not Identify</h3>
        <p className="text-slate-300">{data.errorReason || "The image was unclear or not gym equipment."}</p>
        <button onClick={() => window.location.reload()} className="mt-4 text-emerald-400 hover:underline">Try Again</button>
      </div>
    );
  }

  const youtubeUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(data.youtubeSearchQuery)}`;

  return (
    <div className="bg-slate-800 border border-slate-700 rounded-2xl overflow-hidden shadow-xl animate-fade-in">
      {/* Header Section */}
      <div className="p-6 border-b border-slate-700 bg-slate-800/50">
        <div className="flex justify-between items-start mb-2">
          <div>
            <h2 className="text-2xl sm:text-3xl font-bold text-white mb-1">{data.name}</h2>
            {data.alternativeNames.length > 0 && (
              <p className="text-sm text-slate-400 italic">
                Also known as: {data.alternativeNames.join(', ')}
              </p>
            )}
          </div>
          <DifficultyBadge level={data.difficulty} />
        </div>
        <p className="text-slate-300 mt-4 leading-relaxed">{data.description}</p>
      </div>

      {/* Muscle Groups */}
      <div className="p-6 bg-slate-900/30">
        <h3 className="flex items-center gap-2 text-emerald-400 font-semibold mb-3 uppercase text-xs tracking-wider">
          <Activity className="w-4 h-4" /> Targeted Muscles
        </h3>
        <div className="flex flex-wrap gap-2">
          {data.primaryMuscles.map((muscle, idx) => (
            <span key={idx} className="bg-slate-700 text-white px-3 py-1 rounded-md text-sm">
              {muscle}
            </span>
          ))}
        </div>
      </div>

      {/* Safety Tips */}
      <div className="p-6">
        <h3 className="flex items-center gap-2 text-yellow-400 font-semibold mb-3 uppercase text-xs tracking-wider">
          <CheckCircle className="w-4 h-4" /> Safety Essentials
        </h3>
        <ul className="space-y-3">
          {data.safetyTips.map((tip, idx) => (
            <li key={idx} className="flex gap-3 text-slate-300 text-sm">
              <span className="block w-1.5 h-1.5 rounded-full bg-yellow-500 mt-1.5 shrink-0" />
              {tip}
            </li>
          ))}
        </ul>
      </div>

      {/* Actions */}
      <div className="p-6 border-t border-slate-700 bg-slate-800/50">
        <a
          href={youtubeUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="w-full flex items-center justify-center gap-2 bg-red-600 hover:bg-red-700 text-white font-semibold py-3 px-6 rounded-xl transition-all transform hover:scale-[1.02] shadow-lg shadow-red-900/20"
        >
          <Youtube className="w-5 h-5" />
          Watch Video Tutorial
        </a>
        <p className="text-center text-slate-500 text-xs mt-3">
          Opens YouTube search results for certified tutorials
        </p>
        
        <div className="mt-6 text-center">
          <button 
            onClick={onSuggestCorrection}
            className="text-xs text-slate-500 hover:text-slate-300 transition-colors flex items-center justify-center gap-1.5 mx-auto"
          >
            <Flag className="w-3 h-3" />
            Not the right machine? Suggest a correction
          </button>
        </div>
      </div>
    </div>
  );
};