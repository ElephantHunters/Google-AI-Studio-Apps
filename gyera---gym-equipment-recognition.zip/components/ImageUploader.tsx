import React, { useCallback, useRef } from 'react';
import { Upload, Camera, Image as ImageIcon } from 'lucide-react';

interface ImageUploaderProps {
  onImageSelected: (base64: string) => void;
  disabled?: boolean;
}

export const ImageUploader: React.FC<ImageUploaderProps> = ({ onImageSelected, disabled }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const processFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      alert('Please upload a valid image file.');
      return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = reader.result as string;
      // Remove the data URL prefix (e.g., "data:image/jpeg;base64,")
      const base64Data = base64String.split(',')[1];
      onImageSelected(base64Data);
    };
    reader.readAsDataURL(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    if (disabled) return;
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  }, [disabled]);

  const handleDragOver = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
  }, []);

  return (
    <div className="w-full">
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        accept="image/*"
        className="hidden"
        disabled={disabled}
      />
      
      <div 
        onClick={() => !disabled && fileInputRef.current?.click()}
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        className={`
          relative group cursor-pointer
          border-2 border-dashed border-slate-700 hover:border-emerald-500
          rounded-2xl p-8 sm:p-12 transition-all duration-300
          bg-slate-800/50 hover:bg-slate-800
          flex flex-col items-center justify-center text-center
          ${disabled ? 'opacity-50 cursor-not-allowed' : ''}
        `}
      >
        <div className="w-16 h-16 bg-slate-900 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300 shadow-lg shadow-emerald-500/10">
          <Camera className="w-8 h-8 text-emerald-400" />
        </div>
        
        <h3 className="text-lg font-semibold text-white mb-2">
          Snap or Upload Equipment
        </h3>
        <p className="text-slate-400 text-sm max-w-xs mx-auto mb-6">
          Take a clear photo of the machine. We'll identify it and show you how to use it.
        </p>

        <div className="flex gap-3">
          <button className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-medium rounded-lg transition-colors flex items-center gap-2">
            <Upload className="w-4 h-4" /> Select Photo
          </button>
        </div>

        <p className="mt-4 text-xs text-slate-500">
          Supports JPG, PNG, HEIC
        </p>
      </div>
    </div>
  );
};