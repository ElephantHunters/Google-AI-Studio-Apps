import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="py-8 px-4 text-center border-t border-slate-800 mt-12">
      <div className="max-w-2xl mx-auto">
        <p className="text-slate-500 text-xs leading-relaxed">
          <span className="font-bold text-slate-400">Disclaimer:</span> GYERA uses AI to identify equipment. Always consult with a certified gym trainer if you are unsure how to use a machine. Start with light weights to prevent injury. This app does not process or store images of individuals.
        </p>
        <p className="text-slate-600 text-xs mt-4">
          © {new Date().getFullYear()} GYERA. Powered by Google Gemini.
        </p>
      </div>
    </footer>
  );
};