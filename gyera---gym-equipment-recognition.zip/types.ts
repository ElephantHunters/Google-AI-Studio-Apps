export enum DifficultyLevel {
  Beginner = "Beginner",
  Intermediate = "Intermediate",
  Advanced = "Advanced"
}

export interface EquipmentData {
  identified: boolean;
  name: string;
  alternativeNames: string[];
  description: string;
  primaryMuscles: string[];
  secondaryMuscles?: string[];
  difficulty: DifficultyLevel;
  youtubeSearchQuery: string;
  safetyTips: string[];
  errorReason?: string;
}

export interface AnalysisState {
  status: 'idle' | 'analyzing' | 'success' | 'error';
  data: EquipmentData | null;
  errorMessage: string | null;
  imagePreview: string | null;
}