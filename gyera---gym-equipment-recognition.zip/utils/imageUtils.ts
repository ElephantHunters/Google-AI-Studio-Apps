
export interface BoundingBox {
  ymin: number;
  xmin: number;
  ymax: number;
  xmax: number;
}

export const blurFaces = async (base64Data: string, boxes: BoundingBox[]): Promise<string> => {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext('2d');
      
      if (!ctx) {
        resolve(base64Data);
        return;
      }

      // Draw the original image
      ctx.drawImage(img, 0, 0);

      // Apply blur to each face region
      boxes.forEach(box => {
        // Convert normalized coordinates (0-1) to pixel coordinates
        // Ensure coordinates are within bounds
        const ymin = Math.max(0, box.ymin);
        const xmin = Math.max(0, box.xmin);
        const ymax = Math.min(1, box.ymax);
        const xmax = Math.min(1, box.xmax);

        const x = xmin * img.width;
        const y = ymin * img.height;
        const w = (xmax - xmin) * img.width;
        const h = (ymax - ymin) * img.height;

        // Basic validation to avoid invalid rects
        if (w <= 0 || h <= 0) return;

        ctx.save();
        ctx.beginPath();
        ctx.rect(x, y, w, h);
        ctx.clip();
        
        // Apply Gaussian blur
        // 20px blur radius is generally sufficient for privacy
        ctx.filter = 'blur(20px)'; 
        
        // Draw the image again over the clipped region
        // We draw slightly larger to avoid hard edges if possible, but standard draw is fine with clip
        ctx.drawImage(img, 0, 0);
        
        ctx.restore();
      });

      // Return as base64 string (without prefix)
      const result = canvas.toDataURL('image/jpeg', 0.9);
      resolve(result.split(',')[1]);
    };
    img.onerror = (e) => reject(new Error("Failed to load image for processing"));
    img.src = `data:image/jpeg;base64,${base64Data}`;
  });
};
